function Vm(){
var df =(document.getElementById("df").value);
var di =(document.getElementById("di").value);
var tf =(document.getElementById("tf").value);
var ti =(document.getElementById("ti").value);
var vm;
vm=(df-di)/(tf-ti);
document.getElementById("mostrador").value = vm;
}